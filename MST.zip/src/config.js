module.exports = {
  prefix: "!",
  owner: "581142001739628565",
  token:
    "MTIyOTI2MzAyMzg5NDQzMzg1Mg.GZCW_e.7zZ0S487juribljsj9niOKgu13anTZSXC2tNhY",
};
